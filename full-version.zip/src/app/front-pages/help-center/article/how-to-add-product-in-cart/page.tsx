// Component Imports
import Questions from '@views/front-pages/help-center/Questions'

const Article = () => {
  return <Questions />
}

export default Article
