// Component Imports
import HelpCenterWrapper from '@views/front-pages/help-center'

function HelpCenterPage() {
  return <HelpCenterWrapper />
}

export default HelpCenterPage
