// Component Imports
import ChatWrapper from '@views/apps/chat'

const ChatApp = () => {
  return <ChatWrapper />
}

export default ChatApp
