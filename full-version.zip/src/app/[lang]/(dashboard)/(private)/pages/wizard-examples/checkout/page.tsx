// Component Imports
import CheckoutWizard from '@views/pages/wizard-examples/checkout'

const CheckoutPage = () => {
  return <CheckoutWizard />
}

export default CheckoutPage
